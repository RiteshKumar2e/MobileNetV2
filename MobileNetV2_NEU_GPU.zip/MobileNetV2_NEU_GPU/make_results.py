"""Collect every headline number from paper_results/ into one file:
paper_results/results.csv  (one row per model/variant, same columns everywhere).

    python make_results.py

Safe to re-run at any time; sections whose source table does not exist yet are
skipped (and listed at the end).
"""
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent / "paper_results"
TABLES = ROOT / "tables"
OUT = ROOT / "results.csv"

COLUMNS = ["Section", "Model", "Task", "Seeds", "Accuracy (%)", "Macro-F1 (%)",
           "AP50", "AP75", "mAP50_95", "Params", "MACs (M)", "CPU latency (ms)",
           "Source", "Notes"]

rows, missing = [], []


def read(path):
    if path.exists():
        return pd.read_csv(path)
    missing.append(str(path.relative_to(ROOT)))
    return None


def mean_sd(series):
    s = pd.to_numeric(series, errors="coerce").dropna()
    if s.empty:
        return ""
    return f"{s.mean():.2f} +- {s.std(ddof=1):.2f}" if len(s) > 1 else f"{s.iloc[0]:.2f}"


# 1. Section 13b: controlled multi-seed classification protocol
proto_dirs = sorted(ROOT.glob("protocol_*"), key=lambda p: p.stat().st_mtime)
if proto_dirs:
    pdir = proto_dirs[-1]
    df = read(pdir / "table_protocol_main.csv")
    if df is not None:
        for _, r in df.iterrows():
            rows.append({"Section": "1. Classification protocol (multi-seed)",
                         "Model": r["Model"], "Task": "classification",
                         "Seeds": r["Runs"], "Accuracy (%)": r["Accuracy (%)"],
                         "Macro-F1 (%)": r["Macro-F1 (%)"],
                         "Params": f'{r["Params (M)"]} M', "MACs (M)": r["MACs (M)"],
                         "CPU latency (ms)": r["CPU latency (ms/img)"],
                         "Source": f"{pdir.name}/table_protocol_main.csv"})
else:
    missing.append("protocol_*/table_protocol_main.csv")

# 2. Proposed model, multi-seed (classification + CAM localization)
df = read(TABLES / "table_multiseed.csv")
if df is not None:
    for _, r in df.iterrows():
        rows.append({"Section": "2. Proposed model (multi-seed)", "Model": r["Model"],
                     "Task": "classification + weakly-supervised localization",
                     "Seeds": r["Seeds"], "Accuracy (%)": r["accuracy"],
                     "Macro-F1 (%)": r["f1_macro"], "AP50": r["AP50"],
                     "AP75": r["AP75"], "mAP50_95": r["mAP50_95"],
                     "Source": "tables/table_multiseed.csv"})

# 3. Backbone comparison (single seed)
df = read(TABLES / "table_classification_comparison.csv")
if df is not None:
    for _, r in df.iterrows():
        rows.append({"Section": "3. Backbone comparison (seed 42)", "Model": r["Model"],
                     "Task": r["Task"], "Seeds": 1, "Accuracy (%)": r["Accuracy"],
                     "Macro-F1 (%)": r["F1"], "Params": r["Params"],
                     "MACs (M)": r["MACs (M)"], "CPU latency (ms)": r["Latency ms"],
                     "Source": "tables/table_classification_comparison.csv",
                     "Notes": f'init={r["Init"]}'})

# 4. Ablations: multi-seed mean +- sd if available, else the seed-42 table
ms = read(TABLES / "table_ablation_multiseed.csv")
if ms is not None:
    for (study, variant), g in ms.groupby(["Study", "Variant"], sort=False):
        rows.append({"Section": "4. Ablation (multi-seed)", "Model": variant,
                     "Task": study, "Seeds": g["seed"].nunique(),
                     "Accuracy (%)": mean_sd(g["Accuracy"]),
                     "Macro-F1 (%)": mean_sd(g["F1_macro"]), "AP50": mean_sd(g["AP50"]),
                     "AP75": mean_sd(g["AP75"]), "mAP50_95": mean_sd(g["mAP50_95"]),
                     "Params": int(g["Params"].iloc[0]),
                     "Source": "tables/table_ablation_multiseed.csv",
                     "Notes": f'seeds={sorted(g["seed"].unique().tolist())}'})
else:
    missing.pop()                      # fall back silently to the single-seed table
    df = read(TABLES / "table_ablation.csv")
    if df is not None:
        for _, r in df.iterrows():
            rows.append({"Section": "4. Ablation (seed 42)", "Model": r["Variant"],
                         "Task": r["Study"], "Seeds": 1, "Accuracy (%)": r["Accuracy"],
                         "Macro-F1 (%)": r["F1_macro"], "AP50": round(r["AP50"], 2),
                         "AP75": round(r["AP75"], 2), "mAP50_95": round(r["mAP50_95"], 2),
                         "Params": r["Params"], "Source": "tables/table_ablation.csv"})

# 5. Detection / localization: every AP number scored by the same AP code
df = read(TABLES / "table_final_comparison.csv")
if df is not None:
    yolo = read(TABLES / "table_yolo_baselines.csv")
    lat = {} if yolo is None else dict(zip(yolo["Model"], yolo["Latency ms (median)"]))
    for _, r in df.iterrows():
        rows.append({"Section": "5. Detection / localization (test split)",
                     "Model": r["Model"], "Task": r["Task"], "Seeds": 1,
                     "AP50": r["AP50"], "AP75": r["AP75"], "mAP50_95": r["mAP50_95"],
                     "Params": "" if pd.isna(r["Params"]) else int(r["Params"]),
                     "Source": "tables/table_final_comparison.csv",
                     "Notes": (f'GPU latency {lat[r["Model"]]} ms' if r["Model"] in lat else "")})

# 6. Efficiency
df = read(TABLES / "table_efficiency.csv")
if df is not None:
    for _, r in df.iterrows():
        rows.append({"Section": "6. Efficiency", "Model": r["Model"], "Task": "inference cost",
                     "Params": r["Params (total)"], "MACs (M)": r["MACs (M)"],
                     "CPU latency (ms)": r["CPU latency ms (median)"],
                     "Source": "tables/table_efficiency.csv",
                     "Notes": (f'size {r["Size (MiB)"]} MiB; GPU {r["GPU latency ms (median)"]} ms '
                               f'({r["GPU FPS"]} FPS)')})

out = pd.DataFrame(rows, columns=COLUMNS)
out["Seeds"] = pd.to_numeric(out["Seeds"], errors="coerce").astype("Int64")
out.to_csv(OUT, index=False)
print(f"Wrote {len(out)} rows -> {OUT}")
print(out.groupby("Section", sort=False).size().to_string())
if missing:
    print("\nNot available yet (skipped):\n  " + "\n  ".join(missing))
