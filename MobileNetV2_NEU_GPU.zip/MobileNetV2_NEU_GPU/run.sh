#!/usr/bin/env bash
# Usage: bash run.sh [stages...]     e.g.  bash run.sh protocol section13
# Runs in the background with nohup, so it survives an SSH disconnect.
# Log: logs/run_<timestamp>.log    Follow it with: tail -f logs/run_*.log
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p logs
STAGES="${*:-protocol}"
LOG="logs/run_$(date +%Y%m%d_%H%M%S).log"
nohup python -u run.py --stage $STAGES > "$LOG" 2>&1 &
echo "started PID $! -- stages: $STAGES -- log: $LOG"
