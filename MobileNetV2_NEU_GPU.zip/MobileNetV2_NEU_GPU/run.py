"""Headless runner for new_model_code.ipynb (NEU-DET) -- for GPU servers / Colab.

Executes the notebook's own cells, in order, in one Python namespace: first the
setup cells (Sections 0-12: config, ground truth, frozen split, pipeline, model,
training/eval/metric definitions), then only the stages you ask for. Cells are
located by their section headings, so nothing here duplicates notebook code.

    python run.py --stage check                 # setup only + GPU report
    python run.py --stage protocol --quick      # 2-epoch smoke test of Section 13b
    python run.py --stage protocol              # main experiment: 6 models x 5 seeds
    python run.py --stage protocol section13 detection sdf_yolo

Stages
    check              setup cells only
    protocol           Section 13b  controlled multi-seed protocol (results_per_run.csv)
    section13          Section 13   headline model, ablation studies, YOLO baselines
    detection          Sections 14-16  supervised FCOS detector vs APG-inspired detector
    sdf_yolo           Sections 17-18  SDF-YOLO
    ablation_multiseed Section 22   ablation studies A+B at the remaining seeds

Everything is written under ./paper_results/. Runs are resumable where the
notebook supports it (Section 13b skips completed (model, seed) rows).
"""
import argparse
import json
import os
import re
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
os.chdir(HERE)                                   # notebook resolves NEU-DET from cwd
os.environ.setdefault("MPLBACKEND", "Agg")       # no display on a server
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")


def _use_legacy_keras_if_needed():
    """TF >= 2.16 ships Keras 3; the notebook is written for Keras 2 (tf.keras).
    There, with the `tf-keras` package installed, TF_USE_LEGACY_KERAS=1 keeps
    tf.keras on Keras 2. On TF <= 2.15 the flag must NOT be set: it makes TF look
    for tf_keras and `import tensorflow.keras` fails."""
    from importlib import metadata
    try:
        major, minor = (int(x) for x in metadata.version("tensorflow").split(".")[:2])
    except Exception:
        return
    if (major, minor) >= (2, 16):
        try:
            metadata.version("tf-keras")
        except metadata.PackageNotFoundError:
            raise SystemExit("TensorFlow >= 2.16 needs the tf-keras package for this "
                             "notebook: pip install -r requirements-py312.txt")
        os.environ.setdefault("TF_USE_LEGACY_KERAS", "1")


_use_legacy_keras_if_needed()

# Windows: TF and torch each ship a cudnn64_8.dll. Whichever loads first wins the
# process-wide name; if TF goes first, torch's cuDNN sub-libraries fail to load
# (WinError 127) when the YOLO stages import ultralytics. Loading torch first
# makes both use torch's cuDNN 8.x, which TF 2.10 accepts.
try:
    import torch  # noqa: F401
except ImportError:
    pass

NOTEBOOK = HERE / "new_model_code.ipynb"

# (first heading of the stage, heading where it stops -- exclusive)
STAGES = {
    "protocol":           ("## Section 13b", "## What still has to happen"),
    "section13":          ("## Section 13 - Run everything", "## Section 13b"),
    "detection":          ("## Section 14", "## Section 17"),
    "sdf_yolo":           ("## Section 17", "## Section 22"),
    "ablation_multiseed": ("## Section 22", None),
}
SETUP_END = "## Section 13 - Run everything"


def load_cells():
    nb = json.loads(NOTEBOOK.read_text(encoding="utf-8"))
    return [(c["cell_type"], "".join(c["source"])) for c in nb["cells"]]


def heading_index(cells, prefix):
    for i, (kind, src) in enumerate(cells):
        if kind == "markdown" and src.startswith(prefix):
            return i
    raise SystemExit(f"heading not found in notebook: {prefix!r}")


def code_between(cells, start, end):
    a = heading_index(cells, start) if start else 0
    b = heading_index(cells, end) if end else len(cells)
    return [(i, src) for i, (kind, src) in enumerate(cells[a:b], a) if kind == "code"]


def set_flag(src, name, value):
    """Rewrite a top-level `NAME = ...` assignment in a cell, or fail loudly."""
    pat = re.compile(rf"^{name} = [^#\n]*?(?=[ \t]*(#|$))", re.M)
    if not pat.search(src):
        raise SystemExit(f"could not find `{name} = ...` to override")
    return pat.sub(f"{name} = {value!r}", src, count=1)


def overrides(src, quick):
    """Apply --quick/full to whichever switches this cell contains."""
    for name in ("QUICK", "QUICK_PROTOCOL", "QUICK_DET"):
        if re.search(rf"^{name} = ", src, re.M):
            src = set_flag(src, name, quick)
    if re.search(r"^SDF_YOLO_EPOCHS = ", src, re.M):
        src = set_flag(src, "SDF_YOLO_EPOCHS", 3 if quick else 100)
    if re.search(r"^RUN_ABLATION_MULTISEED = ", src, re.M):
        src = set_flag(src, "RUN_ABLATION_MULTISEED", True)
    return src


def _patch_h5_checkpoints_for_old_tf(tf):
    """TF < 2.13 (e.g. 2.10, the last native-Windows GPU build) writes
    `*.weights.h5` as legacy H5, which stores each layer's weights in
    trainable-then-non-trainable order. The notebook saves a checkpoint in the
    frozen phase and restores it after unfreezing, so that order changes and
    load_weights fails ("axes don't match array"). On those versions, route
    checkpoint `.weights.h5` paths through TF's object-based checkpoint format
    (written next to it as `<path>.tf*`; `<path>` itself is touched so the
    notebook's `ckpt.exists()` checks still work). `size_probe_*` files are
    left as H5 because their on-disk size is the reported metric."""
    major, minor = (int(x) for x in tf.__version__.split(".")[:2])
    if (major, minor) >= (2, 13):
        return
    Model = tf.keras.Model
    orig_save, orig_load = Model.save_weights, Model.load_weights

    def redirected(fp):
        p = str(fp)
        return p.endswith(".weights.h5") and not Path(p).name.startswith("size_probe_")

    def save_weights(self, filepath, overwrite=True, save_format=None, options=None):
        if not redirected(filepath):
            return orig_save(self, filepath, overwrite=overwrite,
                             save_format=save_format, options=options)
        orig_save(self, str(filepath) + ".tf", overwrite=overwrite, save_format="tf",
                  options=options)
        Path(filepath).touch()

    def load_weights(self, filepath, by_name=False, skip_mismatch=False, options=None):
        if redirected(filepath) and Path(str(filepath) + ".tf.index").exists():
            return orig_load(self, str(filepath) + ".tf", options=options)
        return orig_load(self, filepath, by_name=by_name,
                         skip_mismatch=skip_mismatch, options=options)

    Model.save_weights, Model.load_weights = save_weights, load_weights
    print(f"TF {tf.__version__} < 2.13: checkpoint .weights.h5 -> TF checkpoint format")


DUP_DEFAULT = "    exclude_val_stems: tuple = ()"
DUP_DROPPED = '    exclude_val_stems: tuple = ("patches_105",)'


def run_cells(label, cells, g, quick, drop_dup=False):
    for i, src in cells:
        t0 = time.time()
        print(f"\n{'#' * 78}\n# [{label}] notebook cell {i}\n{'#' * 78}", flush=True)
        src = overrides(src, quick)
        if drop_dup and DUP_DEFAULT in src:
            src = src.replace(DUP_DEFAULT, DUP_DROPPED)
        exec(compile(src, f"<notebook cell {i}>", "exec"), g)
        print(f"# [{label}] cell {i} done in {time.time() - t0:.1f}s", flush=True)


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--stage", nargs="+", default=["protocol"],
                    choices=["check", *STAGES], help="what to run after setup")
    ap.add_argument("--quick", action="store_true",
                    help="2-epoch smoke test (numbers are NOT reportable)")
    ap.add_argument("--drop-val-duplicate", action="store_true",
                    help="drop patches_105 from validation (byte-identical to "
                         "patches_101 in train); results go to a new protocol folder")
    args = ap.parse_args()

    if not (HERE / "NEU-DET" / "IMAGES").exists():
        raise SystemExit(f"NEU-DET/ not found in {HERE}. The dataset must sit next to "
                         f"run.py -- re-extract MobileNetV2_NEU_GPU.zip completely.")

    cells = load_cells()
    g = {"__name__": "__main__"}
    t0 = time.time()
    run_cells("setup", code_between(cells, None, SETUP_END), g, args.quick,
              drop_dup=args.drop_val_duplicate)
    if args.drop_val_duplicate and len(g["VAL_DF"]) != 179:
        raise SystemExit("--drop-val-duplicate did not take effect (validation is not 179 images)")

    tf = g["tf"]
    _patch_h5_checkpoints_for_old_tf(tf)
    gpus = tf.config.list_physical_devices("GPU")
    print(f"\nTensorFlow {tf.__version__} | GPUs: {gpus or 'NONE -- running on CPU'}")
    print(f"Mode: {'QUICK smoke test' if args.quick else 'FULL protocol'} | "
          f"stages: {args.stage} | results: {g['CFG'].results_dir}")
    if not gpus:
        print("WARNING: no GPU visible to TensorFlow. See README_RUN.md (CUDA setup).")

    for stage in args.stage:
        if stage == "check":
            continue
        run_cells(stage, code_between(cells, *STAGES[stage]), g, args.quick,
                  drop_dup=args.drop_val_duplicate)

    print(f"\nFinished {args.stage} in {(time.time() - t0) / 3600:.2f} h")


if __name__ == "__main__":
    sys.exit(main())
