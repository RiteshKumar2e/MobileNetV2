# Steel defect (NEU-DET): running on a GPU machine

## What is in this folder

| Path | What it is |
|---|---|
| `new_model_code.ipynb` | The notebook (NEU-DET only). Old outputs are cleared. |
| `NEU-DET/` | Dataset: 1,800 images (`IMAGES/<class>/`) + 1,800 VOC XML files (`ANNOTATIONS/`) |
| `paper_results/splits/split_v1.csv` | The **frozen** train/val/test split (1260/180/360). Do not delete it, or a new split gets generated and the old numbers stop being comparable. |
| `yolov8n.pt`, `yolo11n.pt`, `yolo12n.pt` | Pretrained YOLO weights (only for the YOLO stages) |
| `run.py` | Headless runner: executes the notebook's own cells, no Jupyter needed |
| `run.sh` | Starts `run.py` in the background with a log file (Linux) |
| `requirements.txt` | Tested packages (Python 3.10/3.11, TensorFlow 2.15) |
| `requirements-py312.txt` | For Python 3.12 / current Colab (TF 2.18 + tf-keras, untested) |

## 1. Linux GPU server (recommended)

```bash
unzip MobileNetV2_NEU_GPU.zip && cd MobileNetV2_NEU_GPU

# Python 3.10 or 3.11
python3.10 -m venv .venv && source .venv/bin/activate
pip install -U pip
pip install -r requirements.txt

# 1) Is the GPU visible? Must print "GPUs: [PhysicalDevice(... GPU:0 ...)]"
python run.py --stage check

# 2) Smoke test (~minutes on a GPU). Numbers are NOT reportable.
python run.py --stage protocol --quick

# 3) The real run, in the background (survives SSH disconnect)
bash run.sh protocol
tail -f logs/run_*.log
```

## 2. Google Colab

```python
from google.colab import drive; drive.mount('/content/drive')
!unzip -q /content/drive/MyDrive/MobileNetV2_NEU_GPU.zip -d /content/
%cd /content/MobileNetV2_NEU_GPU
!python --version
# Python 3.10/3.11 -> requirements.txt ; Python 3.12 -> requirements-py312.txt
!pip install -q -r requirements-py312.txt
!python run.py --stage check
!python run.py --stage protocol --quick
!python run.py --stage protocol
```

Colab disconnects after a few hours. Section 13b is **resumable**: copy
`paper_results/` back to Drive regularly. After a disconnect, restore it and run
the same command again. Completed (model, seed) runs are skipped.

```python
!cp -r paper_results /content/drive/MyDrive/neu_paper_results_backup
```

## 3. Windows (native GPU, as used for the 22-Oct-2026 results)

TF 2.10 is the last TensorFlow with native Windows GPU support. This is the setup
that produced the reported results (RTX 3060, Python 3.10.11):

```powershell
py -3.10 -m venv C:\neu310        # short path: the TF 2.10 wheel exceeds MAX_PATH otherwise
C:\neu310\Scripts\pip install torch==2.3.1 torchvision==0.18.1 --index-url https://download.pytorch.org/whl/cu118
C:\neu310\Scripts\pip install -r requirements-win-gpu.txt
powershell -ExecutionPolicy Bypass -File run_all_gpu.ps1      # all stages, with retries + logs\status.txt
```

`run.py` loads torch before TensorFlow (cuDNN DLL clash) and, on TF < 2.13, stores
checkpoints in TF's object format. Both are needed on TF 2.10; do not remove them.

## Stages

| Command | Runs | Rough cost |
|---|---|---|
| `python run.py --stage check` | setup only + GPU report | 1 min |
| `python run.py --stage protocol` | **Section 13b, the main experiment.** 6 models × 5 seeds under one protocol: MobileNetV2, +FPN, +FPN+AMFF, Full (CSAF+SEAM), +FPN+SE, +FPN+CBAM | 30 training runs |
| `python run.py --stage section13` | Section 13: 5-seed headline model + per-class/confusion + CAM localization + efficiency + backbone comparison + all ablation studies + YOLO baselines (100 epochs) | largest |
| `python run.py --stage detection` | Sections 14–16: supervised FCOS detector vs APG-inspired detector | medium |
| `python run.py --stage sdf_yolo` | Sections 17–18: SDF-YOLO, 100 epochs | medium |
| `python run.py --stage ablation_multiseed` | Section 22: ablation A+B at 4 extra seeds | large |

Several stages can be combined: `bash run.sh protocol section13`.
Add `--quick` to any stage for a 2-epoch smoke test.

**Duplicate-free rerun (optional).** `patches_105` (validation) is byte-identical to
`patches_101` (training). The reported results keep it, and the paper discloses it.
To rerun without it:

```bash
python run.py --stage protocol section13 detection ablation_multiseed --drop-val-duplicate
```

Validation becomes 179 images and the test set is unchanged. The protocol id changes,
so the new results land in a new `paper_results/protocol_<id>/` folder and never mix
with the old ones. Section 13, the detection stage and the ablation write to
`paper_results/tables/`, so **copy the existing `paper_results/` somewhere safe first**.

## Results: what to put in the paper

After `protocol`, everything is in `paper_results/protocol_<id>/`:

- `table_protocol_main.csv`: accuracy / macro-F1 / P / R as **mean ± sd over 5 seeds**, plus params, MACs and latency
- `table_protocol_paired.csv`: each model vs the full model, paired per seed
- `table_protocol_per_class_f1.csv`: per-class F1 (inclusion-class discussion)
- `results_per_run.csv`: one row per (model, seed), the source of truth
- `predictions/*.npz`: raw test softmax, so every metric can be recomputed
- `manifest.json`: the exact protocol that produced these numbers

The `<id>` is a hash of the protocol (epochs, LR, loss, split). Quick runs and
full runs therefore land in **different folders** and can never be mixed.

Latency in `table_protocol_main.csv` is measured **on CPU**, batch 1. If you
quote GPU latency, take it from `section13` → `tables/table_efficiency.csv`
(GPU columns appear automatically when a GPU is present), and state the GPU model.

## Notes

- Checkpoints are selected on **validation** macro-F1 (tie-break: val loss). The
  test set is evaluated once per run, after selection. Never pick a seed by test accuracy.
- Known dataset issue: `patches_101` (train) and `patches_105` (val) are the
  same image. No test image is affected; mention it in the paper.
- GPU runs are not bit-for-bit identical to CPU runs. Report mean ± sd, not single runs.
