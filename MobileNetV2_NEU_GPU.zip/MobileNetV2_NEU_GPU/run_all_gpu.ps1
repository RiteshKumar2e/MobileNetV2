# Native Windows GPU runner (RTX, TF 2.10 in C:\neu310). SDF-YOLO is intentionally skipped.
# Start detached:  Start-Process powershell -WindowStyle Hidden -ArgumentList '-NoProfile -ExecutionPolicy Bypass -File run_all_gpu.ps1'
# Progress:        Get-Content logs\status.txt ; Get-Content logs\<stage>_*.log -Tail 30 -Wait
# A stage that finished writes logs\done_<stage>.ok and is skipped on a re-launch.
# Delete that file to run the stage again. Section 13b (protocol) resumes per (model, seed).
param([string[]]$Stages = @("protocol", "section13", "detection", "ablation_multiseed"),
      [int]$MaxAttempts = 3)

Set-Location $PSScriptRoot
New-Item -ItemType Directory -Force logs | Out-Null
# Venv lives at a short path: TF 2.10's wheel exceeds MAX_PATH under the project folder.
$venv = "C:\neu310"
$py = Join-Path $venv "Scripts\python.exe"
$status = Join-Path $PSScriptRoot "logs\status.txt"
function Say($msg) { "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  $msg" | Tee-Object -FilePath $status -Append }

# CUDA 11 / cuDNN 8 DLLs come from the nvidia-* pip wheels; TF finds them via PATH.
$nv = Get-ChildItem (Join-Path $venv "Lib\site-packages\nvidia") -Directory |
      ForEach-Object { Join-Path $_.FullName "bin" } | Where-Object { Test-Path $_ }
$env:PATH = (($nv + @($env:PATH)) -join ";")
$env:PYTHONUNBUFFERED = "1"
$env:PYTHONIOENCODING = "utf-8"
$env:MPLBACKEND = "Agg"

# Keep Windows awake (no sleep) for as long as this script runs.
Add-Type -Namespace Win32 -Name Power -MemberDefinition '[DllImport("kernel32.dll")] public static extern uint SetThreadExecutionState(uint f);'
[Win32.Power]::SetThreadExecutionState([uint32]"0x80000001") | Out-Null

Say "runner started (PID $PID), stages: $($Stages -join ' ')"
foreach ($stage in $Stages) {
    $done = Join-Path $PSScriptRoot "logs\done_$stage.ok"
    if (Test-Path $done) { Say "skip $stage (already done)"; continue }
    for ($try = 1; $try -le $MaxAttempts; $try++) {
        $log = "logs\${stage}_$(Get-Date -Format 'yyyyMMdd_HHmmss')_try$try.log"
        Say "start $stage (attempt $try) -> $log"
        cmd /c "`"$py`" -u run.py --stage $stage > `"$log`" 2>&1"
        $code = $LASTEXITCODE
        if ($code -eq 0) { Say "DONE $stage"; New-Item -ItemType File -Force $done | Out-Null; break }
        Say "FAILED $stage (exit $code) -- see $log"
        if ($try -lt $MaxAttempts) { Start-Sleep 60 }
    }
}
Say "runner finished"
[Win32.Power]::SetThreadExecutionState([uint32]"0x80000000") | Out-Null
