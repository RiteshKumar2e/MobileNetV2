#!/usr/bin/env bash
# Runs inside tensorflow/tensorflow:2.15.0-gpu with the project mounted at /work.
set -euo pipefail
cd /work
mkdir -p logs
LOG="logs/run_gpu_$(date +%Y%m%d_%H%M%S).log"
exec > >(tee -a "$LOG") 2>&1
echo "log: $LOG"

apt-get update -qq && apt-get install -y -qq libgl1 libglib2.0-0 > /dev/null
# TF 2.15 GPU comes with the image; install everything else from requirements.txt.
grep -v '^tensorflow' requirements.txt > /tmp/req.txt
pip install -q -r /tmp/req.txt

python - <<'EOF'
import tensorflow as tf
gpus = tf.config.list_physical_devices("GPU")
print("TF", tf.__version__, "GPUs:", gpus)
assert gpus, "No GPU visible inside the container -- aborting."
EOF

python -u run.py --stage protocol section13 detection sdf_yolo ablation_multiseed
echo "ALL STAGES DONE"
